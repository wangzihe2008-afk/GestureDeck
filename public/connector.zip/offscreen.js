// src/vision/FrameRate.ts
var FrameRate = class {
  times = [];
  add(time) {
    this.times.push(time);
    while (this.times.length > 1 && time - this.times[0] > 1500) this.times.shift();
  }
  get(now) {
    const last = this.times.at(-1);
    const elapsed = last === void 0 ? 0 : last - this.times[0];
    if (last === void 0 || now - last > 1500 || elapsed <= 0) return 0;
    return Math.round((this.times.length - 1) * 1e3 / elapsed);
  }
  reset() {
    this.times = [];
  }
};

// connector/src/BackgroundCamera.ts
var FRAME_INTERVAL_MS = 50;
var BackgroundCamera = class {
  constructor(onPacket, onError, onCameraFrame) {
    this.onPacket = onPacket;
    this.onError = onError;
    this.onCameraFrame = onCameraFrame;
  }
  onPacket;
  onError;
  onCameraFrame;
  stream = null;
  worker = null;
  workerReady = false;
  pendingSince = null;
  workerStartedAt = 0;
  reader = null;
  watchdog;
  generation = 0;
  running = false;
  lastFrameAt = 0;
  nextFrameAt = 0;
  lastTimestamp = -Infinity;
  captureRate = new FrameRate();
  recognitionRate = new FrameRate();
  async start(assetBase) {
    this.stop();
    const token = this.generation;
    const Processor = globalThis.MediaStreamTrackProcessor;
    if (!Processor)
      throw new Error(
        "Direct background camera capture is unavailable. Update desktop Chrome and reload the connector."
      );
    if (!navigator.mediaDevices?.getUserMedia)
      throw new Error(
        "Camera access is unavailable. Open GestureDeck in desktop Chrome at localhost."
      );
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 480 },
          height: { ideal: 360 },
          frameRate: { ideal: 30, max: 30 }
        },
        audio: false
      });
      if (token !== this.generation) {
        stream.getTracks().forEach((track2) => track2.stop());
        return;
      }
      this.stream = stream;
      const track = stream.getVideoTracks()[0];
      const processor = new Processor({ track, maxBufferSize: 1 });
      const reader = processor.readable.getReader();
      this.reader = reader;
      this.running = true;
      this.lastFrameAt = performance.now();
      this.nextFrameAt = 0;
      this.lastTimestamp = -Infinity;
      this.startWorker(assetBase, token);
      track.onended = () => {
        if (this.running) this.fail("The camera disconnected. Restart the camera check.");
      };
      this.watchdog = setInterval(() => {
        const now = performance.now();
        if (now - this.lastFrameAt > 8e3)
          this.fail("The camera stopped delivering frames. Restart the camera check.");
        else if (!this.workerReady && now - this.workerStartedAt > 3e4)
          this.fail("The pose model did not finish loading. Restart the camera check.");
        else if (this.pendingSince !== null && now - this.pendingSince > 8e3)
          this.fail("Pose recognition stopped responding. Restart the camera check.");
      }, 1e3);
      void this.consume(reader, token);
    } catch (exception) {
      if (token !== this.generation) return;
      this.stop();
      const error = exception;
      if (error.name === "NotAllowedError")
        throw new Error(
          "Allow the connector to use the camera in Chrome and your system privacy settings."
        );
      if (error.name === "NotReadableError")
        throw new Error(
          "The camera is busy. Close other camera apps, then restart the camera check."
        );
      throw error;
    }
  }
  getInfo() {
    const track = this.stream?.getVideoTracks()[0];
    const settings = track?.getSettings();
    return {
      label: track?.label || "Camera",
      width: settings?.width,
      height: settings?.height,
      captureFps: this.captureRate.get(performance.now())
    };
  }
  startWorker(assetBase, token) {
    const worker = new Worker(new URL("pose-worker.js", assetBase));
    this.worker = worker;
    this.workerStartedAt = performance.now();
    worker.onmessage = ({ data }) => {
      if (token !== this.generation) return;
      if (data.type === "READY") this.workerReady = true;
      if (data.type === "ERROR") this.fail(`Background recognition stopped: ${data.message}`);
      if (data.type === "POSE") {
        this.pendingSince = null;
        const now = performance.now();
        this.recognitionRate.add(now);
        this.onPacket({ ...data.packet, fps: this.recognitionRate.get(now) });
      }
    };
    worker.onerror = (error) => {
      if (token === this.generation)
        this.fail(`Could not run the background pose model: ${error.message}`);
    };
    const request = { type: "INIT", assetBase };
    worker.postMessage(request);
  }
  async consume(reader, token) {
    try {
      while (this.running && token === this.generation) {
        const { value: frame, done } = await reader.read();
        if (done) {
          if (token === this.generation && this.running)
            this.fail("The camera stream ended. Restart the camera check.");
          return;
        }
        let transferred = false;
        try {
          if (!this.running || token !== this.generation) return;
          const now = performance.now();
          this.lastFrameAt = now;
          if (frame.timestamp <= this.lastTimestamp || !frame.displayWidth || !frame.displayHeight)
            continue;
          this.lastTimestamp = frame.timestamp;
          this.captureRate.add(now);
          this.onCameraFrame?.(frame, now);
          if (!this.workerReady || this.pendingSince !== null || now < this.nextFrameAt) continue;
          this.nextFrameAt = now - this.nextFrameAt > FRAME_INTERVAL_MS ? now + FRAME_INTERVAL_MS : this.nextFrameAt + FRAME_INTERVAL_MS;
          this.pendingSince = now;
          const request = { type: "FRAME", frame, time: now };
          this.worker.postMessage(request, [frame]);
          transferred = true;
        } finally {
          if (!transferred) frame.close();
        }
      }
    } catch (exception) {
      if (token === this.generation && this.running)
        this.fail(`Background recognition stopped: ${exception.message}`);
    } finally {
      reader.releaseLock();
    }
  }
  fail(message) {
    this.stop();
    this.onError(message);
  }
  stop() {
    this.generation++;
    this.running = false;
    clearInterval(this.watchdog);
    this.watchdog = void 0;
    const reader = this.reader;
    this.reader = null;
    if (reader) void reader.cancel().catch(() => {
    });
    this.stream?.getTracks().forEach((track) => {
      track.onended = null;
      track.stop();
    });
    this.stream = null;
    this.worker?.terminate();
    this.worker = null;
    this.workerReady = false;
    this.pendingSince = null;
    this.captureRate.reset();
    this.recognitionRate.reset();
  }
};

// src/core/normalize.ts
var JOINTS = [11, 12, 13, 14, 15, 16];
var FEATURE_SIZE = JOINTS.length * 2;
function frameDistance(a, b) {
  if (a.length !== FEATURE_SIZE || b.length !== FEATURE_SIZE) return Infinity;
  const weights = [0.25, 0.25, 0.8, 0.8, 1.4, 1.4];
  let sum = 0, weight = 0;
  for (let i = 0; i < weights.length; i++) {
    sum += weights[i] * ((a[i * 2] - b[i * 2]) ** 2 + (a[i * 2 + 1] - b[i * 2 + 1]) ** 2);
    weight += weights[i];
  }
  return Math.sqrt(sum / weight);
}
function representativePose(frames) {
  if (!frames.length) return [];
  return Array.from({ length: FEATURE_SIZE }, (_, index) => {
    const values = frames.map((frame) => frame.values[index]).sort((a, b) => a - b);
    const middle = Math.floor(values.length / 2);
    return values.length % 2 ? values[middle] : (values[middle - 1] + values[middle]) / 2;
  });
}

// src/core/dtw.ts
function dtwDistance(a, b, bandRatio = 0.35) {
  if (!a.length || !b.length) return Infinity;
  const n = a.length, m = b.length, band = Math.max(Math.abs(n - m), Math.ceil(Math.max(n, m) * bandRatio));
  const cost = Array.from({ length: n + 1 }, () => new Float64Array(m + 1).fill(Infinity));
  const lengths = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
  cost[0][0] = 0;
  for (let i = 1; i <= n; i++)
    for (let j = Math.max(1, i - band); j <= Math.min(m, i + band); j++) {
      let pi = i - 1, pj = j - 1;
      if (cost[i - 1][j] < cost[pi][pj]) {
        pi = i - 1;
        pj = j;
      }
      if (cost[i][j - 1] < cost[pi][pj]) {
        pi = i;
        pj = j - 1;
      }
      cost[i][j] = cost[pi][pj] + frameDistance(a[i - 1].values, b[j - 1].values);
      lengths[i][j] = lengths[pi][pj] + 1;
    }
  return lengths[n][m] ? cost[n][m] / lengths[n][m] : Infinity;
}
function resample(frames, count = 24) {
  if (frames.length < 2) return frames.map((f) => ({ ...f, values: [...f.values] }));
  const first = frames[0].t, duration = frames.at(-1).t - first;
  if (duration <= 0) return [];
  let cursor = 0;
  return Array.from({ length: count }, (_, i) => {
    const t = first + duration * i / (count - 1);
    while (cursor < frames.length - 2 && frames[cursor + 1].t < t) cursor++;
    const a = frames[cursor], b = frames[cursor + 1];
    const mix = Math.max(0, Math.min(1, (t - a.t) / Math.max(1, b.t - a.t)));
    return { t: t - first, values: a.values.map((v, d) => v + (b.values[d] - v) * mix) };
  });
}
var distanceToScore = (distance) => Math.round(100 * Math.exp(-2.5 * distance));

// src/core/recognizer.ts
var GestureRecognizer = class {
  constructor(gestures, onCommand, options = {}) {
    this.gestures = gestures;
    this.onCommand = onCommand;
    this.options = options;
  }
  gestures;
  onCommand;
  options;
  buffer = [];
  lastFrame = -Infinity;
  lastCheck = -Infinity;
  cooldownUntil = 0;
  released = true;
  releaseCount = 0;
  releasePose = null;
  releaseStartPoses = [];
  releaseDistance = 0.18;
  releaseStartTolerance = 0.18;
  releaseRequiredFrames = 3;
  candidate = "";
  candidateSince = 0;
  confirmations = 0;
  enabled = false;
  status = { state: "PAUSED", candidate: "", score: 0, progress: 0 };
  setTemplates(gestures) {
    this.gestures = gestures;
    this.reset();
  }
  setEnabled(enabled) {
    this.enabled = enabled;
    this.reset();
  }
  isEnabled() {
    return this.enabled;
  }
  reset() {
    this.buffer = [];
    this.lastFrame = -Infinity;
    this.lastCheck = -Infinity;
    this.candidate = "";
    this.candidateSince = 0;
    this.confirmations = 0;
    this.released = true;
    this.releasePose = null;
    this.releaseStartPoses = [];
    this.releaseCount = 0;
    this.releaseDistance = 0.18;
    this.releaseStartTolerance = 0.18;
    this.releaseRequiredFrames = 3;
    this.cooldownUntil = 0;
    this.status = {
      state: this.enabled ? "READY" : "PAUSED",
      candidate: "",
      score: 0,
      progress: 0
    };
  }
  push(frame, now) {
    if (!this.enabled)
      return this.status = { state: "PAUSED", candidate: "", score: 0, progress: 0 };
    if (!frame) {
      this.buffer = [];
      this.resetMatching();
      return this.status = { state: "NO_POSE", candidate: "", score: 0, progress: 0 };
    }
    const frameGap = frame.t - this.lastFrame;
    if (frameGap > 300) {
      this.buffer = [];
      const candidateGesture = this.gestures.find((gesture) => gesture.id === this.candidate);
      if (candidateGesture?.mode !== "pose") this.resetMatching();
    }
    if (frameGap > 1800) this.resetMatching();
    this.lastFrame = frame.t;
    const coolingDown = now < this.cooldownUntil;
    if (coolingDown && !this.options.releaseDuringCooldown)
      return this.status = { state: "COOLDOWN", candidate: "", score: 0, progress: 0 };
    if (!this.released && this.releasePose) {
      const distanceFromEnd = frameDistance(frame.values, this.releasePose);
      const returnedToStart = this.releaseStartPoses.some((startPose) => {
        const distanceFromStart = frameDistance(frame.values, startPose);
        return distanceFromStart <= this.releaseStartTolerance && distanceFromStart + 0.04 < distanceFromEnd;
      });
      const leftEndPose = distanceFromEnd >= this.releaseDistance;
      this.releaseCount = returnedToStart || leftEndPose ? this.releaseCount + 1 : 0;
      if (this.releaseCount < this.releaseRequiredFrames)
        return this.status = {
          state: coolingDown ? "COOLDOWN" : "RELEASE",
          candidate: "",
          score: 0,
          progress: 0
        };
      this.released = true;
      this.buffer = [];
      this.releaseCount = 0;
      this.releasePose = null;
      this.releaseStartPoses = [];
      this.resetMatching();
    }
    if (coolingDown)
      return this.status = { state: "COOLDOWN", candidate: "", score: 0, progress: 0 };
    this.buffer.push(frame);
    this.buffer = this.buffer.filter((f) => frame.t - f.t <= 2400);
    if (now - this.lastCheck < 80) return this.status;
    this.lastCheck = now;
    const matches = this.match(frame);
    const best = matches[0];
    const mode = best?.gesture.mode ?? "motion";
    const requiredMargin = mode === "pose" ? 0.045 : 0.055;
    if (!best || best.distance > best.gesture.threshold || best.margin < requiredMargin) {
      this.resetMatching();
      return this.status = {
        state: "READY",
        candidate: best?.gesture.name ?? "",
        score: best?.score ?? 0,
        progress: 0
      };
    }
    if (this.candidate === best.gesture.id) {
      this.confirmations++;
    } else {
      this.candidate = best.gesture.id;
      this.candidateSince = now;
      this.confirmations = 1;
    }
    this.candidate = best.gesture.id;
    const heldFor = now - this.candidateSince;
    const confirmed = mode === "pose" ? this.confirmations >= 2 && heldFor >= 180 : this.confirmations >= 2;
    this.status = {
      state: "MATCHING",
      candidate: best.gesture.name,
      score: best.score,
      progress: mode === "pose" ? Math.min(1, Math.max(this.confirmations / 3, heldFor / 180)) : this.confirmations / 2
    };
    if (confirmed) {
      this.cooldownUntil = now + best.gesture.cooldownMs;
      this.released = false;
      this.releasePose = [...frame.values];
      if (mode === "pose") {
        this.releaseStartPoses = [];
        this.releaseDistance = Math.min(0.36, Math.max(0.24, best.gesture.threshold * 1.25));
        this.releaseStartTolerance = 0.18;
        this.releaseRequiredFrames = 2;
      } else {
        const endpointDistances = best.gesture.samples.map(
          (sample) => frameDistance(sample[0].values, sample.at(-1).values)
        );
        const endpointTravel = Math.min(...endpointDistances.filter(Number.isFinite));
        this.releaseStartPoses = best.gesture.samples.map((sample) => [...sample[0].values]);
        this.releaseDistance = Math.min(0.24, Math.max(0.1, endpointTravel * 0.45));
        this.releaseStartTolerance = Math.min(0.2, Math.max(0.1, endpointTravel * 0.35));
        this.releaseRequiredFrames = 3;
      }
      this.releaseCount = 0;
      this.buffer = [];
      this.resetMatching();
      this.status = {
        state: "COOLDOWN",
        candidate: best.gesture.name,
        score: best.score,
        progress: 1
      };
      this.onCommand({
        command: best.gesture.command,
        name: best.gesture.name,
        score: best.score,
        time: Date.now()
      });
    }
    return this.status;
  }
  resetMatching() {
    this.candidate = "";
    this.candidateSince = 0;
    this.confirmations = 0;
  }
  match(frame) {
    const matches = [];
    for (const gesture of this.gestures.filter((g) => g.enabled)) {
      let distance = Infinity;
      if (gesture.mode === "pose") {
        const distances = gesture.samples.map(
          (sample) => frameDistance(frame.values, representativePose(sample))
        );
        distance = distances.reduce((total, value) => total + value, 0) / distances.length;
      } else {
        for (const sample of gesture.samples) {
          const duration = sample.at(-1).t;
          for (const ratio of [0.65, 0.85, 1, 1.2]) {
            const end = this.buffer.at(-1)?.t ?? 0;
            const window = this.buffer.filter((f) => f.t >= end - duration * ratio);
            if (window.length < 10 || window.at(-1).t - window[0].t < duration * ratio * 0.8)
              continue;
            const startDistance = frameDistance(window[0].values, sample[0].values);
            const endDistance = frameDistance(window.at(-1).values, sample.at(-1).values);
            if (endDistance > Math.min(0.28, gesture.threshold * 0.9) || startDistance > 0.35)
              continue;
            const endpoint = (startDistance + endDistance) / 2;
            distance = Math.min(
              distance,
              dtwDistance(resample(window), sample) * 0.8 + endpoint * 0.2
            );
          }
        }
      }
      if (Number.isFinite(distance))
        matches.push({ gesture, distance, score: distanceToScore(distance), margin: Infinity });
    }
    matches.sort((a, b) => a.distance - b.distance);
    if (matches.length > 1) matches[0].margin = matches[1].distance - matches[0].distance;
    return matches;
  }
};

// src/core/types.ts
var COMMANDS = [
  "NEXT_SLIDE",
  "PREVIOUS_SLIDE",
  "BLACK_SCREEN",
  "TOGGLE_CONTROL"
];

// src/core/storage.ts
function validateTemplates(value) {
  if (!Array.isArray(value) || value.length > 30)
    throw new Error("A profile can contain up to 30 poses.");
  const ids = /* @__PURE__ */ new Set();
  for (const g of value) {
    if (!g || typeof g.id !== "string" || g.id.length > 100 || ids.has(g.id) || typeof g.name !== "string" || !g.name.trim() || g.name.length > 40 || !COMMANDS.includes(g.command) || g.mode !== void 0 && g.mode !== "pose" && g.mode !== "motion" || typeof g.enabled !== "boolean")
      throw new Error("Invalid gesture profile format.");
    ids.add(g.id);
    if (!Number.isFinite(g.threshold) || g.threshold < 0.1 || g.threshold > 0.5 || !Number.isFinite(g.cooldownMs) || g.cooldownMs < 600 || g.cooldownMs > 5e3)
      throw new Error("Threshold or cooldown is outside the allowed range.");
    if (typeof g.createdAt !== "string" || !Array.isArray(g.samples) || g.samples.length !== 2)
      throw new Error(
        "The saved pose data is incomplete. Capture this pose again or import a valid backup."
      );
    const mode = g.mode ?? "motion";
    for (const sample of g.samples) {
      const minimumFrames = mode === "pose" ? 4 : 12;
      const maximumFrames = mode === "pose" ? 30 : 80;
      if (!Array.isArray(sample) || sample.length < minimumFrames || sample.length > maximumFrames)
        throw new Error("Gesture frame count is outside the allowed range.");
      let last = -1;
      for (const f of sample) {
        if (!Number.isFinite(f.t) || f.t <= last || f.t < 0 || f.t > (mode === "pose" ? 1100 : 2200) || !Array.isArray(f.values) || f.values.length !== FEATURE_SIZE || f.values.some(
          (v) => typeof v !== "number" || !Number.isFinite(v) || Math.abs(v) > 20
        ))
          throw new Error("Invalid gesture pose data.");
        last = f.t;
      }
      if (sample[0].t !== 0 || last < (mode === "pose" ? 250 : 650))
        throw new Error("Invalid gesture timestamps.");
    }
  }
  return value.map((gesture) => ({
    ...gesture,
    mode: gesture.mode ?? "motion"
  }));
}

// src/vision/drawing.ts
var BONES = [
  [11, 12],
  [11, 13],
  [13, 15],
  [12, 14],
  [14, 16],
  [11, 23],
  [12, 24],
  [23, 24]
];
function drawSkeleton(canvas, points) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const { width: w, height: h } = canvas;
  ctx.clearRect(0, 0, w, h);
  const visible = (i) => Boolean(
    points[i] && Number.isFinite(points[i].x) && Number.isFinite(points[i].y) && (points[i].visibility ?? 0) > 0.5
  );
  ctx.lineWidth = 3;
  ctx.strokeStyle = "#ccec9e";
  ctx.lineCap = "round";
  for (const [a, b] of BONES)
    if (visible(a) && visible(b)) {
      ctx.beginPath();
      ctx.moveTo(points[a].x * w, points[a].y * h);
      ctx.lineTo(points[b].x * w, points[b].y * h);
      ctx.stroke();
    }
  for (const i of [0, 11, 12, 13, 14, 15, 16, 23, 24])
    if (visible(i)) {
      ctx.beginPath();
      ctx.arc(points[i].x * w, points[i].y * h, 5, 0, Math.PI * 2);
      ctx.fillStyle = [15, 16].includes(i) ? "#f5b881" : "#eaffd5";
      ctx.fill();
    }
}

// connector/src/offscreen.ts
var recognizer = null;
var lastStatus = 0;
var lastState = "";
var lastPreview = 0;
var run = 0;
var readyFrames = 0;
var lastFrameTime = 0;
var readyFrameTarget = 3;
var readyFrameGap = 350;
var recognitionStarted = false;
var recognizedCount = 0;
var paused = false;
var previewEnabled = true;
var previewSending = false;
var latestPose = null;
var PREVIEW_INTERVAL_MS = 50;
var preview = document.getElementById("preview");
var skeleton = document.createElement("canvas");
function previewFrame(source, time) {
  const width = 320;
  const height = Math.round(width * source.displayHeight / source.displayWidth);
  if (preview.width !== width) preview.width = width;
  if (preview.height !== height) preview.height = height;
  if (skeleton.width !== width) skeleton.width = width;
  if (skeleton.height !== height) skeleton.height = height;
  const context = preview.getContext("2d", { alpha: false });
  if (!context) return Promise.resolve(null);
  context.save();
  try {
    context.translate(width, 0);
    context.scale(-1, 1);
    context.drawImage(source, 0, 0, width, height);
    if (latestPose && time - latestPose.time <= 250) {
      drawSkeleton(skeleton, latestPose.landmarks);
      context.drawImage(skeleton, 0, 0);
    }
  } finally {
    context.restore();
  }
  return new Promise((resolve, reject) => {
    preview.toBlob(
      (blob) => {
        if (!blob) return resolve(null);
        const reader = new FileReader();
        reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : null);
        reader.onerror = () => reject(new Error("Could not prepare the live preview."));
        reader.readAsDataURL(blob);
      },
      "image/webp",
      0.52
    );
  });
}
function sendPreview(source, time) {
  if (!previewEnabled || previewSending || time - lastPreview < PREVIEW_INTERVAL_MS) return;
  const token = run;
  lastPreview = time;
  previewSending = true;
  void (async () => {
    try {
      const frame = await previewFrame(source, time);
      if (frame && token === run && previewEnabled && recognizer) {
        await chrome.runtime.sendMessage({
          target: "background",
          type: "OFFSCREEN_PREVIEW",
          preview: frame
        });
      }
    } catch {
    } finally {
      if (token === run) previewSending = false;
    }
  })();
}
var camera = new BackgroundCamera(
  (packet) => {
    latestPose = { time: packet.time, landmarks: packet.landmarks };
    if (packet.frame) {
      readyFrames = packet.time - lastFrameTime <= readyFrameGap ? readyFrames + 1 : 1;
      lastFrameTime = packet.time;
    } else readyFrames = 0;
    const poseReady = readyFrames >= readyFrameTarget;
    if (!recognitionStarted && poseReady) {
      recognitionStarted = true;
      recognizer?.setEnabled(!paused);
    }
    const status = recognizer?.push(packet.frame, packet.time);
    const state = paused ? "PAUSED" : !packet.frame ? "NO_POSE" : !poseReady ? "CHECKING_CAMERA" : status?.state ?? "READY";
    if (packet.time - lastStatus >= 650 || state !== lastState) {
      lastStatus = packet.time;
      lastState = state;
      const info = camera.getInfo();
      void chrome.runtime.sendMessage({
        target: "background",
        type: "OFFSCREEN_STATUS",
        status: { ...status, state },
        poseReady,
        poseMessage: packet.frame && !poseReady ? "Upper body detected. Checking continuous camera frames\u2026" : packet.message,
        poseQuality: packet.quality,
        recognitionFps: packet.fps,
        captureFps: info.captureFps,
        recognizedCount,
        cameraLabel: info.label,
        cameraWidth: info.width ?? packet.width,
        cameraHeight: info.height ?? packet.height
      }).catch(() => {
      });
    }
  },
  (error) => {
    recognizer?.setEnabled(false);
    void chrome.runtime.sendMessage({ target: "background", type: "OFFSCREEN_ERROR", error }).catch(() => {
    });
  },
  sendPreview
);
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || message.target !== "offscreen") return;
  if (message.type === "STOP") {
    run++;
    camera.stop();
    readyFrames = 0;
    recognitionStarted = false;
    previewSending = false;
    latestPose = null;
    recognizer?.setEnabled(false);
    recognizer = null;
    respond({ ok: true });
    return;
  }
  if (message.type === "PAUSE") {
    paused = Boolean(message.paused);
    recognizer?.setEnabled(!paused && recognitionStarted);
    respond({ ok: true });
    return;
  }
  if (message.type === "PREVIEW_VISIBILITY") {
    previewEnabled = Boolean(message.enabled);
    if (previewEnabled) lastPreview = 0;
    respond({ ok: true });
    return;
  }
  if (message.type === "START") {
    const current = ++run;
    void (async () => {
      camera.stop();
      lastStatus = 0;
      lastState = "";
      lastPreview = 0;
      previewSending = false;
      latestPose = null;
      previewEnabled = true;
      readyFrames = 0;
      lastFrameTime = 0;
      recognitionStarted = false;
      recognizedCount = 0;
      paused = false;
      const templates = validateTemplates(message.gestures);
      const poseOnly = templates.filter((gesture) => gesture.enabled).every((gesture) => gesture.mode === "pose");
      readyFrameTarget = poseOnly ? 2 : 3;
      readyFrameGap = poseOnly ? 1600 : 350;
      recognizer = new GestureRecognizer(
        templates,
        (event) => {
          recognizedCount++;
          if (event.command === "TOGGLE_CONTROL") {
            paused = true;
            recognizer?.setEnabled(false);
          }
          void chrome.runtime.sendMessage({ target: "background", type: "OFFSCREEN_COMMAND", event }).catch(() => {
          });
        },
        { releaseDuringCooldown: true }
      );
      await camera.start(chrome.runtime.getURL("/"));
      respond(current === run ? { ok: true } : { error: "Camera check cancelled." });
    })().catch((error) => {
      if (current === run) camera.stop();
      respond({ error: error.message });
    });
    return true;
  }
});
//# sourceMappingURL=offscreen.js.map
